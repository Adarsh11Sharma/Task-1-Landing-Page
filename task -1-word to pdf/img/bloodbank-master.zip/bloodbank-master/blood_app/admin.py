from django.contrib import admin
from .models import District,UserExtend,RequestBlood,BloodGroup


admin.site.register(District)
admin.site.register(UserExtend)
admin.site.register(RequestBlood)
admin.site.register(BloodGroup)
