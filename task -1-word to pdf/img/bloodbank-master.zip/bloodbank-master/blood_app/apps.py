from django.apps import AppConfig


class BloodAppConfig(AppConfig):
    name = 'blood_app'
